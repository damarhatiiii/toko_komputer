console.log("Toko Komputer loaded successfully.");
